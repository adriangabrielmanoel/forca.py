# forca.py
forca
