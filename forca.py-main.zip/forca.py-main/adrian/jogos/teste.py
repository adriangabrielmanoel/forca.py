frutas = ['Pera', 'Panana', 'Melancia', 'Manga', 'Maça','Morango']
fruta_pedida = input('Qual a fruta que deseja?')

if (fruta_pedida in frutas):
    print ('Sim, temos a fruta')
else:
    print('Não temos a fruta')    
    